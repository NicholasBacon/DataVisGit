

import numpy as np
import matplotlib
matplotlib.use('TkAgg')
import matplotlib.pyplot as plt
import csv
import math

def latlon_to_xy(lat, lon, radius=6371):  # Earth's radius in km
    lat_radians = np.radians(lat)
    lon_radians = np.radians(lon)

    x = radius * lon_radians
    y = radius * lat_radians


def haversine(point1, point2):
    lat1= point1[0]
    lon1= point1[1]
    lat2 = point2[0]
    lon2 = point2[1]

    # Radius of Earth in kilometers
    R = 6371

    # Convert degrees to radians
    lat1_rad = math.radians(lat1)
    lon1_rad = math.radians(lon1)
    lat2_rad = math.radians(lat2)
    lon2_rad = math.radians(lon2)

    # Differences between latitudes and longitudes
    dlat = lat2_rad - lat1_rad
    dlon = lon2_rad - lon1_rad

    # Haversine formula
    a = math.sin(dlat / 2) ** 2 + math.cos(lat1_rad) * math.cos(lat2_rad) * math.sin(dlon / 2) ** 2
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))

    # Distance in kilometers
    distance = R * c
    return distance



citys = set()

with open('worldcities.csv', 'r',encoding='utf-8', errors='ignore') as file:
    for line in file:
        ll= line.split(",")[2:4]
        citys.add((float(ll[0]),float(ll[1])))



citysIhavebeento = set()



with open('Timeline.json', 'r') as file:
    for line in file:
        if line.__contains__("°"):
            cleanData = line.replace("Â", "").replace("°", "").replace("\n", "").replace("\"", "").split(":")[1].split( ",")
            point = (float(cleanData[0]),float(cleanData[1]))
            print(len(citysIhavebeento))
            for city in citys:
                if(haversine(point, city)<50):
                    citysIhavebeento.add(city)
                    break


print(citysIhavebeento)







