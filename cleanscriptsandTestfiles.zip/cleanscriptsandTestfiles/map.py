
import csv
import numpy as np
import matplotlib
matplotlib.use('TkAgg')
import matplotlib.pyplot as plt


def latlon_to_xy(lat, lon, radius=6371):  # Earth's radius in km
    lat_radians = np.radians(lat)
    lon_radians = np.radians(lon)

    x = radius * lon_radians
    y = radius * lat_radians

    return float(str(x)), float(str(y))


binsize = 225

lo_min = 35.04
lo_max = 35.23
la_min = -106.75
la_max = -106.49


x = []
y = []
with open('Timeline.json', 'r') as file:
    for line in file:
        if line.__contains__("°"):
            cleanData=  line.replace("Â","").replace("°","").replace("\n","").replace("\"","").split(":")[1].split(",")
            if (lo_min< float(cleanData[0]) and float(cleanData[0]) < lo_max):

                if (la_max > float(cleanData[1]) and float(cleanData[1]) > la_min):
                    xx, yy = latlon_to_xy(float(cleanData[0]), float(cleanData[1]))
                    x.append(xx)
                    y.append(yy)


max_x = max(x)
min_x = min(x)
max_y= max(y)
min_y = min(y)
binsize_x = (max_x - min_x) / binsize*1.1
binsize_y = (max_y-min_y)/binsize*1.1











binedarray = [[2 for i in range(binsize)] for j in range(binsize)]
lastpoint =-1
lastpoint =-1

def euclidean_distance(p1, p2):
    return np.sqrt(np.sum((p2 - p1) ** 2))

def create_line(p1, p2):
    num_points= round(euclidean_distance(p1, p2))+2


    x_values = np.linspace(p1[0], p2[0], num_points)  # Interpolate x values
    y_values = np.linspace(p1[1], p2[1], num_points)
    return np.vstack((x_values, y_values)).T  # Combine into an array of shape (num_points, 2)

# Create the line between the points






oldX = -1
oldY = -1
with open('Timeline.json', 'r') as file:
    for line in file:
        if line.__contains__("°"):
            cleanData = line.replace("Â", "").replace("°", "").replace("\n", "").replace("\"", "").split(":")[1].split( ",")
            if (lo_min < float(cleanData[0]) and float(cleanData[0]) < lo_max):

                if (la_max > float(cleanData[1]) and float(cleanData[1]) > la_min):
                    xx, yy = latlon_to_xy(float(cleanData[0]), float(cleanData[1]))
                    x= int((xx-min_x)/binsize_x)
                    y = int((yy - min_y) / binsize_y)

                    # if(x>100):
                    #     print(cleanData)
                    # binedarray[x][y]=    binedarray[x][y]
                    if oldY != -1:
                        line_points = create_line( np.array([oldX,oldY]) , np.array([x,y]))
                        for points in line_points:
                            binedarray[int(points[0])][int(points[1])] =  binedarray[int(points[0])][int(points[1])]+1

                    oldX= x
                    oldY = y


array_2d = np.array(binedarray)

# Apply the natural logarithm (log base e)


log_array = np.log2(array_2d)





with open('map.csv', mode='w', newline='') as file:
    writer = csv.writer(file)
    writer.writerows(log_array)



plt.imshow(log_array, cmap='viridis')
plt.colorbar()
plt.title("Nicholas Travel Around ABQ")
plt.show()