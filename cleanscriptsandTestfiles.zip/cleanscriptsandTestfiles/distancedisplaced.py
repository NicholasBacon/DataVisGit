
# Function to convert latitude and longitude to x, y (Equirectangular Projection)
def latlon_to_xy(lat, lon, radius=6371):  # Earth's radius in km
    lat_radians = np.radians(lat)
    lon_radians = np.radians(lon)

    x = radius * lon_radians
    y = radius * lat_radians

    return float(str(x)), float(str(y))



import csv

import numpy as np
import matplotlib
matplotlib.use('TkAgg')
import matplotlib.pyplot as plt

binsize = 256
max_x = -11743.413124397215
max_y = 3965.4831558914784
min_x = -11882.90618135746
min_y = 3851.3397512135343
binsize_x = 0.5993842291260556
binsize_y = 0.49045994197554105
lo_min = 34.3
lo_max = 35.8
la_min = -106.9
la_max = -105.6



binedarray = [[1 for i in range(binsize)] for j in range(binsize)]
lastpoint =-1
lastpoint =-1

def euclidean_distance(p1, p2):
    return np.sqrt(np.sum((p2 - p1) ** 2))

def create_line(p1, p2):
    num_points= round(euclidean_distance(p1, p2))+2
    x_values = np.linspace(p1[0], p2[0], num_points)  # Interpolate x values
    y_values = np.linspace(p1[1], p2[1], num_points)
    return np.vstack((x_values, y_values)).T  # Combine into an array of shape (num_points, 2)

# Create the line between the points






oldX = -1
oldY = -1


time = ""
longlat = ""

timeToLL={}



x = 0
with open('C:\\Users\\nicho\\PycharmProjects\\pythonProject15\\Timeline.json', 'r') as file:
    for line in file:
        # if line.__contains__("position"):
        #     time = ""
        #     longlat = ""
        #
        if line.__contains__("startTime"):
            x=x+1
            cleanData = line.replace("\n", "").replace(",", "").split("\":")[1].replace("\"", "").replace(" ", "")
            if not (longlat == ""):
                if not (timeToLL.__contains__(cleanData)):
                    timeToLL[cleanData] = set()

                timeToLL[cleanData].add(longlat)
                longlat = ""
                time = ""
            else:
                time =cleanData


        if line.__contains__("timestamp"):
            x=x+1
            cleanData = line.replace("\n", "").replace(",", "").split("\":")[1].replace("\"", "").replace(" ", "")
            if not (longlat == ""):
                if not (timeToLL.__contains__(cleanData)):
                    timeToLL[cleanData] = set()

                timeToLL[cleanData].add(longlat)
                longlat = ""
                time = ""
            else:
                time =cleanData


        if line.__contains__("°"):
            cleanData = line.replace("Â", "").replace("°", "").replace("\n", "").replace("\"", "").split(":")[1].split( ",")

            xx, yy = latlon_to_xy(float(cleanData[0]), float(cleanData[1]))

            if not (time == ""):

                if not (timeToLL.__contains__(time)):
                    timeToLL[time]= set()
                    # print(timeToLL[time],(xx, yy))

                timeToLL[time].add((xx, yy))
                longlat = ""
                time = ""
            else:
                longlat = (xx, yy)

# print(sorted(timeToLL.keys()))
# print(x)
# for x in sorted(timeToLL.keys()):
#     print(x)

import numpy as np
from scipy.spatial import ConvexHull

def polygon_area(points):
    x = points[:, 0]
    y = points[:, 1]
    return 0.5 * np.abs(np.dot(x, np.roll(y, 1)) - np.dot(y, np.roll(x, 1)))

# Example points


def total_length(points):
    total_dist = 0
    for i in range(1, len(points)):
        # Calculate the Euclidean distance between consecutive points
        dist = np.linalg.norm(points[i] - points[i - 1])
        total_dist += dist
    return total_dist


currentday = ""
daypoints = []
lengths = []
for timestamp in sorted(timeToLL.keys()):
    if len(timestamp) >10:
       day =  timestamp.split("T")[0]
       if (currentday == ""):
           currentday= day
       if currentday != day:

           if len(daypoints) ==0:
               lengths.append(0)
           else:
              length = total_length(np.array(daypoints))
              lengths.append(length)

           currentday =day
           daypoints = []
       for points in  timeToLL[timestamp]:
           daypoints.append([points[0],points[1]])





Q1 = np.percentile(lengths, 25)
Q3 = np.percentile(lengths, 75)
IQR = Q3 - Q1
lower_bound = Q1 - 1.5 * IQR
upper_bound = Q3 + 1.5 * IQR
filtered_lengths= [x+50 for x in lengths if (x >= lower_bound) and  (x <= upper_bound)]

from scipy.fft import dct, idct

# Perform DCT (Type II)
dct_transformed = dct(filtered_lengths, type=2, norm='ortho')[:250]
print("DCT:", dct_transformed)

# Perform IDCT (Type III)
idct_reconstructed = idct(dct_transformed, type=2, norm='ortho')


with open('lengths.csv', mode='w', newline='') as file:
    writer = csv.writer(file)
    writer.writerow(list(map(float,idct_reconstructed)))

plt.plot(idct_reconstructed)
plt.title("Nicholas's distanced traveled the world  ")
plt.xlabel("weeks")
plt.ylabel("length")
plt.show()






