


import numpy as np
import matplotlib


def latlon_to_xy(lat, lon, radius=6371):  # Earth's radius in km
    lat_radians = np.radians(lat)
    lon_radians = np.radians(lon)

    x = radius * lon_radians
    y = radius * lat_radians

    return float(str(x)), float(str(y))

lo_min = 35.04
lo_max = 35.23
la_min = -106.75
la_max = -106.49



x = []
y = []
with open('Timeline.json', 'r') as file:
    for line in file:
        if line.__contains__("°"):
            cleanData=  line.replace("Â","").replace("°","").replace("\n","").replace("\"","").split(":")[1].split(",")
            if (lo_min< float(cleanData[0]) and float(cleanData[0]) < lo_max):

                if (la_max > float(cleanData[1]) and float(cleanData[1]) > la_min):
                    xx, yy = latlon_to_xy(float(cleanData[0]), float(cleanData[1]))
                    x.append(xx)
                    y.append(yy)

binsize= 256
maxX = max(x)
minX = min(x)
maxY= max(y)
minY = min(y)
binX = (maxX - minX) / binsize*1.1
binY = (maxY-minY)/binsize*1.1

print(f"binsize = binsize")
print(f"max_x = maxX")
print(f"max_y = maxY")
print(f"min_x = minX")
print(f"min_y = minY")
print(f"binsize_x = binX*1.1")
print(f"binsize_y = binY*1.1")

print(f"lo_min = {lo_min }")
print(f"lo_max = {lo_max }")
print(f"la_min = {la_min }")
print(f"la_max = {la_max }")

